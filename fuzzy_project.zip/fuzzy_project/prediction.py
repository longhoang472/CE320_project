import cv2
from ultralytics import YOLO

model = YOLO('./best50.pt')

confidence_scores = []
source = './people-detection.mp4'
results = model(source, stream=True)


for result in results:

    frame = result.plot()  # This automatically draws boxes, masks, and keypoints

    cv2.imshow('YOLO Detection', frame)
    for box in result.boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])  # Get bounding box coordinates
        confidence = float(box.conf[0])  # Get confidence score
        confidence_scores.append(confidence)  # Store in list
        
        print(f"Detected object with confidence: {confidence:.2f}")
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()






