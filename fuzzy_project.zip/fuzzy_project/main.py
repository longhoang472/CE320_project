import numpy as np
import skfuzzy as fuzz
import skfuzzy.control as ctrl
from ultralytics import YOLO
import time
import cv2
from datetime import datetime

# Fuzzy variables
confidence = ctrl.Antecedent(np.arange(0, 1.1, 0.1), 'confidence')  
time_of_day = ctrl.Antecedent(np.arange(0, 24, 1), 'time_of_day')  
thief_probability = ctrl.Consequent(np.arange(0, 101, 1), 'thief_probability')  

# Membership functions for confidence score
confidence['low'] = fuzz.trimf(confidence.universe, [0, 0, 0.5])
confidence['medium'] = fuzz.trimf(confidence.universe, [0.3, 0.6, 0.85])
confidence['high'] = fuzz.trimf(confidence.universe, [0.7, 0.9, 1])

# Membership functions for time of day
time_of_day['day'] = fuzz.trimf(time_of_day.universe, [6, 12, 18])  # 6h sang - 6h chieu
time_of_day['night_1'] = fuzz.trimf(time_of_day.universe, [18, 20, 24])  # 6h chieu - 12h dem
time_of_day['night_2'] = fuzz.trimf(time_of_day.universe, [0, 3, 6])    # 12h dem - 6h sang

# Membership functions for thief probability
thief_probability['low'] = fuzz.trimf(thief_probability.universe, [0, 0, 50])
thief_probability['medium'] = fuzz.trimf(thief_probability.universe, [30, 60, 90])
thief_probability['high'] = fuzz.trimf(thief_probability.universe, [70, 100, 100])

# Fuzzy rules 
rule1 = ctrl.Rule(confidence['low'] & time_of_day['day'], thief_probability['low'])
rule2 = ctrl.Rule(confidence['medium'] & time_of_day['day'], thief_probability['medium'])
rule3 = ctrl.Rule(confidence['high'] & time_of_day['day'], thief_probability['medium'])
rule4 = ctrl.Rule(confidence['low'] & time_of_day['night_1'], thief_probability['medium'])
rule5 = ctrl.Rule(confidence['medium'] & time_of_day['night_1'], thief_probability['high'])
rule6 = ctrl.Rule(confidence['high'] & time_of_day['night_1'], thief_probability['high'])
rule7 = ctrl.Rule(confidence['low'] & time_of_day['night_2'], thief_probability['medium'])
rule8 = ctrl.Rule(confidence['medium'] & time_of_day['night_2'], thief_probability['high'])
rule9 = ctrl.Rule(confidence['high'] & time_of_day['night_2'], thief_probability['high'])

# Create Control System
thief_ctrl = ctrl.ControlSystem([rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9])
thief_detector = ctrl.ControlSystemSimulation(thief_ctrl)

model = YOLO('best50.pt')

confidence_scores = []

video_path = 'people-detection.mp4'
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("Error: Could not open video.")
    exit()


while cap.isOpened():

    ret, frame = cap.read()
    if not ret:
        break 

    results = model(frame)

    for result in results:
        frame_with_detections = result.plot()  

        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            confidence_score = float(box.conf[0])
            confidence_scores.append(confidence_score)

            print(f"Detected object with confidence: {confidence_score:.2f}")

            current_time = datetime.now().hour
            #current_time = 23
            print(f"Current time: {current_time} hours")

            thief_detector.input['confidence'] = confidence_score
            thief_detector.input['time_of_day'] = current_time
            thief_detector.compute()

            thief_probability_value = thief_detector.output['thief_probability']

            text = f"Thief Probability: {thief_probability_value:.2f}%"
            cv2.putText(frame_with_detections, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)


        fps = cap.get(cv2.CAP_PROP_FPS)
        print(f"FPS: {fps}")
        
        # Display FPS on frame
        cv2.putText(frame_with_detections, f"FPS: {fps:.0f}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

        cv2.imshow('Thief Probability', frame_with_detections)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


cap.release()
cv2.destroyAllWindows()
