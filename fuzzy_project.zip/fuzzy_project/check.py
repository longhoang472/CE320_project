from ultralytics import YOLO
import cv2

model = YOLO("best70.pt")
#print(model.info())

pic = cv2.imread("people2.jpg")
pic_resized = cv2.resize(pic, (1280, 640))
result = model(pic_resized)
results = result[0].plot()

cv2.imshow("detection", results)
cv2.waitKey(0)
cv2.destroyAllWindows()